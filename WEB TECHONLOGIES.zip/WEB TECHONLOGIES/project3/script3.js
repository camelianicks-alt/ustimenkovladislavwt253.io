// Constructor
const Animal = function (name, sound) {
    this.name = name;
    this.Say = () => sound;
};
// Objects (MUST exist before First is called)
const cat = new Animal("Cat", "Meow");
const dog = new Animal("Dog", "Woof");
const donkey = new Animal("Donkey", "Hee-haw");
const rooster = new Animal("Rooster", "Cock-a-doodle-doo");
// Direct order
const First = () => {
    const arr = [cat, dog, donkey, rooster];
    document.getElementById("demo").innerHTML = "";
    arr.forEach(Go);
};
// Callback
const Go = (item, index) => {
    document.getElementById("demo").innerHTML +=
        item.name + " says " + item.Say() + "<br>";
};
// Shifted
const Second = () => {
    const arr = [cat, dog, donkey, rooster];
    document.getElementById("demo").innerHTML = "";
    arr.forEach(Go2);
};
// Callback with array
const Go2 = (item, index, arr) => {
    const k = (index + 1 < arr.length) ? index + 1 : 0;
    document.getElementById("demo").innerHTML +=
        item.name + " says " + arr[k].Say() + "<br>";
};
