// Object constructors
function Animal(name, sound) {
    this.name = name;
    this.Say = function () {
        return sound;
    };
}
// Create objects
let cat = new Animal("Cat", "Meow");
let dog = new Animal("Dog", "Woof");
let donkey = new Animal("Donkey", "Hee-haw");
let rooster = new Animal("Rooster", "Cock-a-doodle-doo");
// Function 1: Direct order
function First() {
    let arr = [cat, dog, donkey, rooster];
    document.getElementById("demo").innerHTML = "";
    arr.forEach(Go);
}
// forEach callback
function Go(item, index) {
    document.getElementById("demo").innerHTML +=
    item.name + " says " + item.Say() + "<br>";
}
// Function 2: Shifted sounds
function Second() {
    let arr = [cat, dog, donkey, rooster];
    document.getElementById("demo").innerHTML = "";
    arr.forEach(Go2);
}
// forEach callback with array access
function Go2(item, index, arr) {
    let k = (index + 1 < arr.length) ? index + 1 : 0;
    document.getElementById("demo").innerHTML +=
    item.name + " says " + arr[k].Say() + "<br>";
}
